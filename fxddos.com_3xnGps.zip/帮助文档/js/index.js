$(function(){
  $(".ui.top").click(function(){
    $(this).toggleClass("active visible")
    $(".menu.transition").toggleClass("visible")
  })
})

