 
jQuery(function(){
    jQuery(".accordion-title").click(function(e){
        // jQuery(this).find(".accordion-title").addClass("active")
        jQuery(this).next().is(":hidden")
                ? (jQuery(this)
                    .parent()
                    .parent()
                    .find(".accordion-title")
                    .attr("aria-expanded", !1)
                    .removeClass("active")
                    .next()
                    .slideUp(e),
                jQuery(this)
                    .attr("aria-expanded", !jQuery(this).hasClass("active"))
                    .toggleClass("active")
                    .next()
                    .slideDown(e, function () {
                    /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(
                        navigator.userAgent
                    ) &&
                        jQuery.scrollTo(jQuery(this).prev(), {
                        duration: 300,
                        offset: -100
                        });
                    }),
                window.requestAnimationFrame(() => {
                    jQuery.fn.flickity &&
                    jQuery(this)
                        .next()
                        .find("[data-flickity-options].flickity-enabled")
                        .each((t, e) => {
                        jQuery(e).flickity("resize");
                        }),
                    jQuery.fn.packery &&
                        jQuery(this)
                        .next()
                        .find("[data-packery-options]")
                        .packery("layout");
                }))
                : jQuery(this)
                    .parent()
                    .parent()
                    .find(".accordion-title")
                    .attr("aria-expanded", !1)
                    .removeClass("active")
                    .next()
                    .slideUp(e)
                //t.preventDefault();
     })
})
